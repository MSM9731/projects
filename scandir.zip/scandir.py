import os

print('Please wait...')

current_path = os.getcwd()
counter = 0
working = True
filename = 'scandir.txt'

if os.path.isfile(filename):
    os.remove(filename)


def scandir(path):
    global counter, working
    list = os.scandir(path)
    for dir in list:
        entry = os.path.join(path,dir.name)
        file = open(filename, 'a', encoding="utf-8")
        file.write(entry + '\n')
        file.close()
        counter += 1
        if dir.is_dir():
            scandir(entry)


scandir(current_path)



print(counter , 'Record added in', filename)
input('Press enter to exit...')